package p;

public class UmapSportschuheErzeuger extends Erzeuger{

	public UmapSportschuheErzeuger() {
		// TODO Auto-generated constructor stub
	}
	
	public Schuh fabrikmethode() {
		return new UmapSportschuhe();
	}

}
