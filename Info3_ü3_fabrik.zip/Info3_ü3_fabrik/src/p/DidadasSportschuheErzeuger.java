package p;

public class DidadasSportschuheErzeuger extends Erzeuger{

	public DidadasSportschuheErzeuger() {
		
	}
	
	public Schuh fabrikmethode() {
		return new DidadasSportschuhe();
	}

}
