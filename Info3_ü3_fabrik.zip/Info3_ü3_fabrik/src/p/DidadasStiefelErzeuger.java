package p;

public class DidadasStiefelErzeuger extends Erzeuger{

	public DidadasStiefelErzeuger() {
		// TODO Auto-generated constructor stub
	}
	
	public Schuh fabrikmethode() {
		return new DidadasStiefel();
	}

}
