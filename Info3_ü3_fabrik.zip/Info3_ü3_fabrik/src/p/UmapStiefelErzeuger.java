package p;

public class UmapStiefelErzeuger extends Erzeuger{

	public UmapStiefelErzeuger() {
		// TODO Auto-generated constructor stub
	}
	
	public Schuh fabrikmethode() {
		return new UmapStiefel();
	}

}
