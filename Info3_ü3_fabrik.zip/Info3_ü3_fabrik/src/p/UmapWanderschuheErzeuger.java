package p;

public class UmapWanderschuheErzeuger extends Erzeuger{

	public UmapWanderschuheErzeuger() {
		// TODO Auto-generated constructor stub
	}

	public Schuh fabrikmethode() {
		return new UmapWanderschuhe();
	}
}
