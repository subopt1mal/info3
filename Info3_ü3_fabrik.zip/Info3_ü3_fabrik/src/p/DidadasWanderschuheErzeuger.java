package p;

public class DidadasWanderschuheErzeuger extends Erzeuger{

	public DidadasWanderschuheErzeuger() {
		// TODO Auto-generated constructor stub
	}
	
	public Schuh fabrikmethode() {
		return new DidadasWanderschuhe();
	}

}
