package p;

public class EnkiWanderschuheErzeuger extends Erzeuger{

	public EnkiWanderschuheErzeuger() {
		// TODO Auto-generated constructor stub
	}
	
	public Schuh fabrikmethode() {
		return new EnkiWanderschuhe();
	}

}
