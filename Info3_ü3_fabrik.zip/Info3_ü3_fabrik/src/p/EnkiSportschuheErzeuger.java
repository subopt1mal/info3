package p;

public class EnkiSportschuheErzeuger extends Erzeuger{

	public EnkiSportschuheErzeuger() {
		// TODO Auto-generated constructor stub
	}
	
	public Schuh fabrikmethode() {
		return new EnkiSportschuhe();
	}

}
