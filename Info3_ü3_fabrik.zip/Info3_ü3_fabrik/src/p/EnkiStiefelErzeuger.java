package p;

public class EnkiStiefelErzeuger extends Erzeuger{

	public EnkiStiefelErzeuger() {
		// TODO Auto-generated constructor stub
	}
	
	public Schuh fabrikmethode() {
		return new EnkiStiefel();
	}

}
